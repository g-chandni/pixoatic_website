require "test_helper"

class ApplyformTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
