require "test_helper"

class HeaderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
