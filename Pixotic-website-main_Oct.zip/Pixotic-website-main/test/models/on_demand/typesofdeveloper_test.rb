require "test_helper"

class OnDemand::TypesofdeveloperTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
