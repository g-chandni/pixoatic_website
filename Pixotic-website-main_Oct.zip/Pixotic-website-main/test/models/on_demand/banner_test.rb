require "test_helper"

class OnDemand::BannerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
