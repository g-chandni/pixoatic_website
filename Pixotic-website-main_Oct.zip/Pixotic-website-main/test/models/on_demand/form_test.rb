require "test_helper"

class OnDemand::FormTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
