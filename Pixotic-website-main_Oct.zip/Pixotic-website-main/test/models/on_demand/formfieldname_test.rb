require "test_helper"

class OnDemand::FormfieldnameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
