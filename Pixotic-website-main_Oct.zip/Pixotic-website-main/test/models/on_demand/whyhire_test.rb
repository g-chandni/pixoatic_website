require "test_helper"

class OnDemand::WhyhireTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
