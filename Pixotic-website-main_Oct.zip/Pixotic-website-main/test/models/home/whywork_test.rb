require "test_helper"

class Home::WhyworkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
