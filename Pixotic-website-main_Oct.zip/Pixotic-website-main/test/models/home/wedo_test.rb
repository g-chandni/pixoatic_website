require "test_helper"

class Home::WedoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
