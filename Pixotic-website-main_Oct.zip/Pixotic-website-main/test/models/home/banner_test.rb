require "test_helper"

class Home::BannerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
