require "test_helper"

class FooterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
