require "test_helper"

class ServicebannerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
