require "test_helper"

class IndustryserviceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
