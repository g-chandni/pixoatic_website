require "test_helper"

class OurapproachserviceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
