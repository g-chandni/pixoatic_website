require "test_helper"

class Service::TechnologyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
