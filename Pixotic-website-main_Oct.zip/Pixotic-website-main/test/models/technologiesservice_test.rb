require "test_helper"

class TechnologiesserviceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
