module Service
  def self.table_name_prefix
    "service_"
  end
end
