class OnDemand::Typesofdeveloper < ApplicationRecord
end
