class OnDemand::Formfieldname < ApplicationRecord
end
