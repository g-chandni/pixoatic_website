class OnDemand::Whyhire < ApplicationRecord
    has_one_attached :image1
    has_one_attached :image2
    has_one_attached :image3
    has_one_attached :image4
    has_one_attached :image5
    has_one_attached :image6
    has_one_attached :image7
    has_one_attached :image8
end
