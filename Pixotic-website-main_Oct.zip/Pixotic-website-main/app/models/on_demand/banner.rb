class OnDemand::Banner < ApplicationRecord
    has_one_attached :banner
end
