module Home
  def self.table_name_prefix
    "home_"
  end
end
