module OnDemand
  def self.table_name_prefix
    "on_demand_"
  end
end
