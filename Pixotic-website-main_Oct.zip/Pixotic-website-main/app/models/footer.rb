class Footer < ApplicationRecord
end
