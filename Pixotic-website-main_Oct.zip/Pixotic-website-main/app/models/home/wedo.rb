class Home::Wedo < ApplicationRecord
    has_one_attached :image
end
