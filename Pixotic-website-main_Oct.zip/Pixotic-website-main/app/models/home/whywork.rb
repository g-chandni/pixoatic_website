class Home::Whywork < ApplicationRecord
end
