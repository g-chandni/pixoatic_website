class Home::Service < ApplicationRecord
end
