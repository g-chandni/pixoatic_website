class Header < ApplicationRecord
    has_one_attached :logo
end
