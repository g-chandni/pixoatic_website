class ApplicationMailer < ActionMailer::Base
  layout "mailer"
end
